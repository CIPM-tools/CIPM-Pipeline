package dmodel.designtime.monitoring.controller.scale;

public interface IScaleController {

	public boolean shouldLog(String targetId);

}
