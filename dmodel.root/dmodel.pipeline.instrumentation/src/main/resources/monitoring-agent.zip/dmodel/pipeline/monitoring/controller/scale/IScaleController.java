package dmodel.pipeline.monitoring.controller.scale;

public interface IScaleController {

	public boolean shouldLog(String targetId);

}
