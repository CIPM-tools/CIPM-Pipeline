package dmodel.pipeline.monitoring.controller;

public class MonitoringMetadata {

	// RESOURCES
	public static final String RESOURCE_CPU = "_oro4gG3fEdy4YaaT-RYrLQ";

}
